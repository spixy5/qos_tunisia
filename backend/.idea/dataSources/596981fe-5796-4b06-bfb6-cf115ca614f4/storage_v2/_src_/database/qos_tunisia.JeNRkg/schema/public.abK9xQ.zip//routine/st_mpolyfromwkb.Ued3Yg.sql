create function st_mpolyfromwkb(bytea) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
	SELECT CASE WHEN public.ST_GeometryType(public.ST_GeomFromWKB($1)) = 'ST_MultiPolygon'
	THEN public.ST_GeomFromWKB($1)
	ELSE NULL END
	$$;

alter function st_mpolyfromwkb(bytea) owner to postgres;

