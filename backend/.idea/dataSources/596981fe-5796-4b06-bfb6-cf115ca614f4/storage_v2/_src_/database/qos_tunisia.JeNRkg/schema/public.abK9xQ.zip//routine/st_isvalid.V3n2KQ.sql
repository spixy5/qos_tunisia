create function st_isvalid(geometry, integer) returns boolean
    immutable
    strict
    parallel safe
    cost 5000
    language sql
as
$$SELECT (public.ST_isValidDetail($1, $2)).valid$$;

alter function st_isvalid(geometry, integer) owner to postgres;

