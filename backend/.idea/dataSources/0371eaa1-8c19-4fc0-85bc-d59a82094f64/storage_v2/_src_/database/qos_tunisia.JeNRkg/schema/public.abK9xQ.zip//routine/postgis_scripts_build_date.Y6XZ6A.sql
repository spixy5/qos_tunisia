create function postgis_scripts_build_date() returns text
    immutable
    language sql
as
$$SELECT '2026-02-10 06:00:19'::text AS version$$;

alter function postgis_scripts_build_date() owner to postgres;

