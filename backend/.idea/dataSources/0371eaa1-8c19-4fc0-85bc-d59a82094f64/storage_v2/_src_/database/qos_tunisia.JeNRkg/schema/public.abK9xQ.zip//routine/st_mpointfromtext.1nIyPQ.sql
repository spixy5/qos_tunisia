create function st_mpointfromtext(text, integer) returns geometry
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$
	SELECT CASE WHEN public.ST_GeometryType(public.ST_GeomFromText($1, $2)) = 'ST_MultiPoint'
	THEN public.ST_GeomFromText($1, $2)
	ELSE NULL END
	$$;

alter function st_mpointfromtext(text, integer) owner to postgres;

